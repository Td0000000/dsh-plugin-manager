/**
 * Host backend for DSH Plugin Manager:
 * Scans installed DSH plugins, manages persistent groups in td-plugin-groups.json,
 * toggles plugins via cordis.patch.yml (triggers DSH live HMR),
 * and handles plugin uninstallation.
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
export interface Context {
    webServer: {
        register: (opts: {
            kind: 'prefix' | 'exact';
            path: string;
            handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>;
        }) => () => void;
    };
    webRuntime?: {
        trustedHosts?: string[];
    };
    effect: (fn: () => void | (() => void), name?: string) => void;
    /** Read a service without the inject requirement (undefined when absent). */
    get?: (name: string, strict?: boolean) => any;
    logger?: {
        info: (...args: any[]) => void;
        warn: (...args: any[]) => void;
        error: (...args: any[]) => void;
    };
}
export interface PluginInfo {
    id: string;
    name: string;
    version: string;
    description: string;
    author?: string;
    homepage?: string;
    disabled: boolean;
    system: boolean;
    removable: boolean;
    /** `engines.dsh` declared by the plugin package, when it declares one. */
    enginesDsh?: string;
    /**
     * Whether the running DSH version accepts `engines.dsh`: `true`/`false` when
     * the official plugin manager could answer, `null` when unknown.
     */
    compatible?: boolean | null;
}
export interface PluginGroupsData {
    groups: Record<string, string[]>;
    groupOrder: string[];
}
export declare function isSystemPlugin(nameOrId: string): boolean;
/**
 * Resolve the profile this plugin manages.
 *
 * DSH 0.1.x was launched with `--profile <name>`, so the original probe read
 * that flag and otherwise assumed `web`. The 0.2.x launchers (including the
 * Electron Desktop Host) instead pass the profile **directory** positionally
 * (`<dshRoot> <profileDir> <runtimeDir> <pnpm> <bin>`), so the old default sent
 * every read and write to a non-existent `profiles/web` directory. Accept the
 * explicit argument, the `--profile` flag, a positional `…/profiles/<name>`
 * path, `DSH_PROFILE`, then fall back to the only installed profile.
 */
export declare function resolveProfileDir(customProfile?: string): {
    profile: string;
    dir: string;
};
export declare function readGroups(profileDir: string): PluginGroupsData;
export declare function saveGroups(profileDir: string, data: PluginGroupsData): void;
interface PatchEntry {
    id?: string;
    name?: string;
    disabled?: boolean;
    insert?: PatchEntry[];
    [key: string]: any;
}
export declare function readPatchYaml(profileDir: string): PatchEntry[];
export declare function writePatchYaml(profileDir: string, patches: PatchEntry[]): void;
export interface PatchUpdateResult {
    ok: boolean;
    changed: boolean;
    error?: string;
}
/**
 * Persist one entry's enablement in the profile patch by editing only that
 * entry: `disabled: true` is set (added when absent), and enabling removes a
 * switch-only override or drops `disabled` while keeping the rest of the
 * entry's config. Every other patch entry, comment, and `!!js` tag is left as
 * written.
 */
export declare function setPluginEnabledInPatch(profileDir: string, targets: string[], enable: boolean): PatchUpdateResult;
/** Remove every patch entry that targets the given plugin (used on uninstall). */
export declare function removePluginFromPatch(profileDir: string, targets: string[]): PatchUpdateResult;
export declare function scanPlugins(profileDir: string): PluginInfo[];
/**
 * Resolve the Loader entry id a plugin package contributes: a bundle's own
 * `cordis.patch.yml` declares `id`/`name`, and profile patches address that id.
 */
export declare function resolveLoaderEntryId(profileDir: string, id: string): string;
export declare function togglePlugin(profileDir: string, id: string, enable: boolean): {
    ok: boolean;
    error?: string;
};
/**
 * One plugin whose live loader state we want to confirm before responding:
 * `expectEnabled` is the state the toggle is asking for.
 */
export interface SettledTarget {
    id: string;
    expectEnabled: boolean;
}
/**
 * Wait until the live Cordis loader has actually applied a patch change.
 *
 * Writing `cordis.patch.yml` only triggers the HMR watcher asynchronously:
 * the browser must NOT be told to reload before the host entry is enabled /
 * disposed, or the fresh page load would compose a stale client plugin graph
 * (this is exactly why "re-enabling" used to look like a no-op). Poll the
 * loader entry tree until every target reflects the requested state, or the
 * timeout elapses (we still resolve `true` on timeout so the UI can recover
 * via a manual page refresh).
 */
export declare function waitForLoaderSettled(ctx: Context, targets: SettledTarget[], timeoutMs?: number, pollMs?: number): Promise<boolean>;
export declare function togglePluginGroup(profileDir: string, groupName: string, enable: boolean): {
    ok: boolean;
    count: number;
    error?: string;
};
/** Drop the plugin from every saved group without touching the rest of the file. */
export declare function removePluginFromGroups(profileDir: string, id: string): boolean;
export declare function uninstallPlugin(profileDir: string, id: string): {
    ok: boolean;
    error?: string;
};
/** Subset of the official `ChangeResult` we interpret; the service owns the rest. */
export interface ChangeResultLike {
    changed?: boolean;
    application?: 'applied' | 'restart-required' | 'overridden' | 'failed' | 'cancelled';
    error?: {
        code?: string;
        diagnostic?: string;
        incompatible?: unknown[];
    };
    warnings?: string[];
    version?: string;
}
export interface OfficialPluginManagerLike {
    listPlugins?: () => Promise<any[]>;
    setPluginEnabled?: (id: string, enabled: boolean) => Promise<ChangeResultLike>;
    removeBundle?: (name: string) => Promise<ChangeResultLike>;
    listBundles?: () => Promise<any[]>;
}
/** The official service, or `undefined` on hosts that do not provide it. */
export declare function getOfficialPluginManager(ctx: Context): OfficialPluginManagerLike | undefined;
export interface ToggleResult {
    ok: boolean;
    via: 'official' | 'legacy';
    changed?: boolean;
    application?: string;
    error?: string;
    warnings?: string[];
}
/**
 * Enable/disable one plugin: prefer the official service, fall back to editing
 * the profile patch exactly as before when it is absent or refuses.
 */
export declare function togglePluginPreferringOfficial(ctx: Context, profileDir: string, id: string, enable: boolean): Promise<ToggleResult>;
export interface GroupToggleResult {
    ok: boolean;
    count: number;
    error?: string;
    warnings?: string[];
}
export declare function togglePluginGroupPreferringOfficial(ctx: Context, profileDir: string, groupName: string, enable: boolean): Promise<GroupToggleResult>;
export interface UninstallResult {
    ok: boolean;
    via: 'official' | 'legacy';
    error?: string;
    warnings?: string[];
}
/** Uninstall through the official service when it owns the bundle, else by hand. */
export declare function uninstallPluginPreferringOfficial(ctx: Context, profileDir: string, id: string): Promise<UninstallResult>;
/**
 * Fill `compatible` for plugins that declare `engines.dsh`, using the official
 * manager's authoritative compatibility verdict (it knows the running DSH
 * version and saved exemptions). Unknown when the service is absent.
 */
export declare function annotatePluginCompatibility(ctx: Context, plugins: PluginInfo[]): Promise<void>;
export declare const name = "dsh-plugin-manager";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
export {};
//# sourceMappingURL=index.d.ts.map